#ifndef SQLIKE_H_
#define SQLIKE_H_
#include <stdio.h>

void SQLCreateTable();      //f1
void SQLSelectFrom();       //f2
void SQLCreateIndex();      //f3
void SQLSelectWhere();      //f4
void SQLDeleteWhere();      //f5
void SQLInsertInto();       //f6
void SQLUpdateSetWhere();   //f7


#endif