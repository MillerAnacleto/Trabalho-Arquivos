#ifndef SQLIKE_H_
#define SQLIKE_H_
#include <stdio.h>

void SQLCreateTable();
void SQLSelectFrom();
void readBinaryWriteIndex(FILE* file);

#endif